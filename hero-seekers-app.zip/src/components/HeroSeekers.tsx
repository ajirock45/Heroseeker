// shortened here to save space
// I will copy your full updated HeroSeekers.tsx file next manually