import HeroSeekers from './components/HeroSeekers';

function App() {
  return (
    <div>
      <HeroSeekers />
    </div>
  );
}

export default App;